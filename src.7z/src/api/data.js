const APIData = 
{
    isLogin: 0,
    id: '',
    mlm_id: '',
    session_no: '',
    username: '',
    profile_pic: '',
    contact_no: '',
    email: '',
    referral_id: '',
    status: 0,
    verify: 0,
    type: 0,
    latitude: '',
    longitude: '',
    locationTitle: '',
}

export default APIData;
