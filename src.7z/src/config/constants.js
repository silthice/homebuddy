import { Platform } from "react-native";

const constants = {
	clone_URL: "http://phplaravel-559201-1799807.cloudwaysapps.com/api/",
	//live_URL: "https://.com/"
};

export default constants;
